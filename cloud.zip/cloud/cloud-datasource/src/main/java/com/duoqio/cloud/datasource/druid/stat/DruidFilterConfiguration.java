package com.duoqio.cloud.datasource.druid.stat;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;

import com.alibaba.druid.filter.config.ConfigFilter;
import com.alibaba.druid.filter.encoding.EncodingConvertFilter;
import com.alibaba.druid.filter.logging.CommonsLogFilter;
import com.alibaba.druid.filter.logging.Log4j2Filter;
import com.alibaba.druid.filter.logging.Log4jFilter;
import com.alibaba.druid.filter.logging.Slf4jLogFilter;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.wall.WallConfig;
import com.alibaba.druid.wall.WallFilter;

/**
 * 
 *************************************************
 * 功能描述:  DruidFilter的相关配置                  
 * @author  Mr.Chen                   
 * @version 1.0                
 * @date    2019年1月4日 创建文件                                             
 * @see                        
 *************************************************
 */
public class DruidFilterConfiguration {

	@Bean
	@ConfigurationProperties(FILTER_STAT_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_STAT_PREFIX, name = "enabled", matchIfMissing = true)
	@ConditionalOnMissingBean
	public StatFilter statFilter() {
		return new StatFilter();
	}

	@Bean
	@ConfigurationProperties(FILTER_CONFIG_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_CONFIG_PREFIX, name = "enabled")
	@ConditionalOnMissingBean
	public ConfigFilter configFilter() {
		return new ConfigFilter();
	}

	@Bean
	@ConfigurationProperties(FILTER_ENCODING_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_ENCODING_PREFIX, name = "enabled")
	@ConditionalOnMissingBean
	public EncodingConvertFilter encodingConvertFilter() {
		return new EncodingConvertFilter();
	}

	@Bean
	@ConfigurationProperties(FILTER_SLF4J_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_SLF4J_PREFIX, name = "enabled")
	@ConditionalOnMissingBean
	public Slf4jLogFilter slf4jLogFilter() {
		return new Slf4jLogFilter();
	}

	@Bean
	@ConfigurationProperties(FILTER_LOG4J_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_LOG4J_PREFIX, name = "enabled")
	@ConditionalOnMissingBean
	public Log4jFilter log4jFilter() {
		return new Log4jFilter();
	}

	@Bean
	@ConfigurationProperties(FILTER_LOG4J2_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_LOG4J2_PREFIX, name = "enabled")
	@ConditionalOnMissingBean
	public Log4j2Filter log4j2Filter() {
		return new Log4j2Filter();
	}

	@Bean
	@ConfigurationProperties(FILTER_COMMONS_LOG_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_COMMONS_LOG_PREFIX, name = "enabled")
	@ConditionalOnMissingBean
	public CommonsLogFilter commonsLogFilter() {
		return new CommonsLogFilter();
	}

	@Bean
	@ConfigurationProperties(FILTER_WALL_CONFIG_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_WALL_PREFIX, name = "enabled")
	@ConditionalOnMissingBean
	public WallConfig wallConfig() {
		return new WallConfig();
	}

	@Bean
	@ConfigurationProperties(FILTER_WALL_PREFIX)
	@ConditionalOnProperty(prefix = FILTER_WALL_PREFIX, name = "enabled")
	@ConditionalOnMissingBean
	public WallFilter wallFilter(WallConfig wallConfig) {
		WallFilter filter = new WallFilter();
		filter.setConfig(wallConfig);
		return filter;
	}

	private static final String FILTER_STAT_PREFIX = "spring.datasource.druid.filter.stat";
	private static final String FILTER_CONFIG_PREFIX = "spring.datasource.druid.filter.config";
	private static final String FILTER_ENCODING_PREFIX = "spring.datasource.druid.filter.encoding";
	private static final String FILTER_SLF4J_PREFIX = "spring.datasource.druid.filter.slf4j";
	private static final String FILTER_LOG4J_PREFIX = "spring.datasource.druid.filter.log4j";
	private static final String FILTER_LOG4J2_PREFIX = "spring.datasource.druid.filter.log4j2";
	private static final String FILTER_COMMONS_LOG_PREFIX = "spring.datasource.druid.filter.commons-log";
	private static final String FILTER_WALL_PREFIX = "spring.datasource.druid.filter.wall";
	private static final String FILTER_WALL_CONFIG_PREFIX = FILTER_WALL_PREFIX + ".config";

}
