package com.duoqio.cloud.cache.mongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudMongodbApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(CloudMongodbApplication.class, args);
	}
}
