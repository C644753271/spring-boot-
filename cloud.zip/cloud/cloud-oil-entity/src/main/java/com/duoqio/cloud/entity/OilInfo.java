package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the oil_info_tbl database table.
 * 
 */
@Entity
@Table(name="oil_info_tbl")
@NamedEntityGraph(name = "OilInfo.lazy", attributeNodes = {@NamedAttributeNode("oilTypeInfoTbl")})
public class OilInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="oil_id")
	private Integer oilId;

	@Column(name="oil_delete_flag")
	private Short oilDeleteFlag;

	@Column(name="oil_market_price")
	private BigDecimal oilMarketPrice;

	@Column(name="oil_order_count")
	private Integer oilOrderCount;

	@Column(name="oil_price")
	private BigDecimal oilPrice;
	
	@Column(name="oil_batch_id")
	private Integer oilBatchId;

	//bi-directional many-to-one association to OilBrandInfo
//	@OneToMany(mappedBy="oilInfoTbl")
//	private List<OilBrandInfo> oilBrandInfoTbls;

	//bi-directional many-to-one association to OilBrandInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="oil_brand_id")
	@JsonIgnore
	private OilBrandInfo oilBrandInfoTbl;

	//bi-directional many-to-one association to OilStationInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="oil_station_id")
	@JsonIgnore
	private OilStationInfo oilStationInfoTbl;

	//bi-directional many-to-one association to OilTypeInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="oil_type_id")
	private OilTypeInfo oilTypeInfoTbl;

//	//bi-directional many-to-one association to OrderInfo
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="order_id")
//	private OrderInfo orderInfoTbl;

	//bi-directional many-to-one association to OilTypeInfo
//	@OneToMany(mappedBy="oilInfoTbl")
//	private List<OilTypeInfo> oilTypeInfoTbls;

	//bi-directional many-to-one association to OrderInfo
//	@OneToMany(mappedBy="oilInfoTbl")
//	private List<OrderInfo> orderInfoTbls;

	public OilInfo() {
	}

	public Integer getOilId() {
		return this.oilId;
	}

	public void setOilId(Integer oilId) {
		this.oilId = oilId;
	}

	public Short getOilDeleteFlag() {
		return this.oilDeleteFlag;
	}

	public void setOilDeleteFlag(Short oilDeleteFlag) {
		this.oilDeleteFlag = oilDeleteFlag;
	}

	public BigDecimal getOilMarketPrice() {
		return this.oilMarketPrice;
	}

	public void setOilMarketPrice(BigDecimal oilMarketPrice) {
		this.oilMarketPrice = oilMarketPrice;
	}

	public Integer getOilOrderCount() {
		return this.oilOrderCount;
	}

	public void setOilOrderCount(Integer oilOrderCount) {
		this.oilOrderCount = oilOrderCount;
	}

	public BigDecimal getOilPrice() {
		return this.oilPrice;
	}

	public void setOilPrice(BigDecimal oilPrice) {
		this.oilPrice = oilPrice;
	}
	

//	public List<OilBrandInfo> getOilBrandInfoTbls() {
//		return this.oilBrandInfoTbls;
//	}
//
//	public void setOilBrandInfoTbls(List<OilBrandInfo> oilBrandInfoTbls) {
//		this.oilBrandInfoTbls = oilBrandInfoTbls;
//	}

//	public OilBrandInfo addOilBrandInfoTbl(OilBrandInfo oilBrandInfoTbl) {
//		getOilBrandInfoTbls().add(oilBrandInfoTbl);
//		oilBrandInfoTbl.setOilInfoTbl(this);
//
//		return oilBrandInfoTbl;
//	}
//
//	public OilBrandInfo removeOilBrandInfoTbl(OilBrandInfo oilBrandInfoTbl) {
//		getOilBrandInfoTbls().remove(oilBrandInfoTbl);
//		oilBrandInfoTbl.setOilInfoTbl(null);
//
//		return oilBrandInfoTbl;
//	}

	public Integer getOilBatchId() {
		return oilBatchId;
	}

	public void setOilBatchId(Integer oilBatchId) {
		this.oilBatchId = oilBatchId;
	}

	public OilBrandInfo getOilBrandInfoTbl() {
		return this.oilBrandInfoTbl;
	}

	public void setOilBrandInfoTbl(OilBrandInfo oilBrandInfoTbl) {
		this.oilBrandInfoTbl = oilBrandInfoTbl;
	}

	public OilStationInfo getOilStationInfoTbl() {
		return this.oilStationInfoTbl;
	}

	public void setOilStationInfoTbl(OilStationInfo oilStationInfoTbl) {
		this.oilStationInfoTbl = oilStationInfoTbl;
	}

	public OilTypeInfo getOilTypeInfoTbl() {
		return this.oilTypeInfoTbl;
	}

	public void setOilTypeInfoTbl(OilTypeInfo oilTypeInfoTbl) {
		this.oilTypeInfoTbl = oilTypeInfoTbl;
	}

//	public OrderInfo getOrderInfoTbl() {
//		return this.orderInfoTbl;
//	}
//
//	public void setOrderInfoTbl(OrderInfo orderInfoTbl) {
//		this.orderInfoTbl = orderInfoTbl;
//	}

//	public List<OilTypeInfo> getOilTypeInfoTbls() {
//		return this.oilTypeInfoTbls;
//	}
//
//	public void setOilTypeInfoTbls(List<OilTypeInfo> oilTypeInfoTbls) {
//		this.oilTypeInfoTbls = oilTypeInfoTbls;
//	}

	public OilTypeInfo addOilTypeInfoTbl(OilTypeInfo oilTypeInfoTbl) {
		//getOilTypeInfoTbls().add(oilTypeInfoTbl);
		//oilTypeInfoTbl.setOilInfoTbl(this);

		return oilTypeInfoTbl;
	}

	public OilTypeInfo removeOilTypeInfoTbl(OilTypeInfo oilTypeInfoTbl) {
		//getOilTypeInfoTbls().remove(oilTypeInfoTbl);
		//oilTypeInfoTbl.setOilInfoTbl(null);

		return oilTypeInfoTbl;
	}

//	public List<OrderInfo> getOrderInfoTbls() {
//		return this.orderInfoTbls;
//	}
//
//	public void setOrderInfoTbls(List<OrderInfo> orderInfoTbls) {
//		this.orderInfoTbls = orderInfoTbls;
//	}
//
//	public OrderInfo addOrderInfoTbl(OrderInfo orderInfoTbl) {
//		getOrderInfoTbls().add(orderInfoTbl);
//		orderInfoTbl.setOilInfoTbl(this);
//
//		return orderInfoTbl;
//	}
//
//	public OrderInfo removeOrderInfoTbl(OrderInfo orderInfoTbl) {
//		getOrderInfoTbls().remove(orderInfoTbl);
//		orderInfoTbl.setOilInfoTbl(null);
//
//		return orderInfoTbl;
//	}

}