package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the oil_order_info_tbl database table.
 * 
 */
@Entity
@Table(name="oil_order_info_tbl")
@NamedEntityGraph(name = "OilOrderInfo.lazy", attributeNodes = {@NamedAttributeNode("oilCardInfoTbl")})
public class OilOrderInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="oil_order_id")
	private Integer oilOrderId;

	@Column(name="order_deal_status")
	private Short orderDealStatus;

	@Column(name="order_pay_type")
	private Short orderPayType;

	@Column(name="order_price")
	private BigDecimal orderPrice;

	@Column(name="order_status")
	private Integer orderStatus;

	@Column(name="order_tran_no")
	private String orderTranNo;

	@Column(name="order_transaction_id")
	private Integer orderTransactionId;

	@Temporal(TemporalType.DATE)
	@Column(name="add_time")
	private Date addTime;

	@Column(name="delete_flag")
	private Short deleteFlag;

	//bi-directional many-to-one association to OilCardInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="oil_card_id")
	private OilCardInfo oilCardInfoTbl;

	//bi-directional many-to-one association to UserInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	@JsonIgnore
	private UserInfo userInfoTbl;

	public OilOrderInfo() {
	}

	public Integer getOilOrderId() {
		return this.oilOrderId;
	}

	public void setOilOrderId(Integer oilOrderId) {
		this.oilOrderId = oilOrderId;
	}

	public Short getOrderDealStatus() {
		return this.orderDealStatus;
	}

	public void setOrderDealStatus(Short orderDealStatus) {
		this.orderDealStatus = orderDealStatus;
	}

	public Short getOrderPayType() {
		return this.orderPayType;
	}

	public void setOrderPayType(Short orderPayType) {
		this.orderPayType = orderPayType;
	}

	public BigDecimal getOrderPrice() {
		return this.orderPrice;
	}

	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}

	public Integer getOrderStatus() {
		return this.orderStatus;
	}

	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderTranNo() {
		return this.orderTranNo;
	}

	public void setOrderTranNo(String orderTranNo) {
		this.orderTranNo = orderTranNo;
	}

	public Integer getOrderTransactionId() {
		return this.orderTransactionId;
	}

	public void setOrderTransactionId(Integer orderTransactionId) {
		this.orderTransactionId = orderTransactionId;
	}

	public Date getAddTime() {
		return this.addTime;
	}

	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}

	public Short getDeleteFlag() {
		return this.deleteFlag;
	}

	public void setDeleteFlag(Short deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public OilCardInfo getOilCardInfoTbl() {
		return this.oilCardInfoTbl;
	}

	public void setOilCardInfoTbl(OilCardInfo oilCardInfoTbl) {
		this.oilCardInfoTbl = oilCardInfoTbl;
	}

	public UserInfo getUserInfoTbl() {
		return this.userInfoTbl;
	}

	public void setUserInfoTbl(UserInfo userInfoTbl) {
		this.userInfoTbl = userInfoTbl;
	}

}