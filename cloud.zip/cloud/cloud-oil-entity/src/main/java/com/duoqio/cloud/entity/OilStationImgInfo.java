package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;



/**
 * The persistent class for the oil_station_img_info_tbl database table.
 * 
 */
@Entity
@Table(name="oil_station_img_info_tbl")
public class OilStationImgInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="oil_station_img_id")
	private Integer oilStationImgId;

	@Column(name="oil_station_img")
	private String oilStationImg;

	@Column(name="oil_station_img_delete_flag")
	private Short oilStationImgDeleteFlag;

	//bi-directional many-to-one association to OilStationInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="oil_station_id")
	private OilStationInfo oilStationInfoTbl;

	public OilStationImgInfo() {
	}

	public Integer getOilStationImgId() {
		return this.oilStationImgId;
	}

	public void setOilStationImgId(Integer oilStationImgId) {
		this.oilStationImgId = oilStationImgId;
	}

	public String getOilStationImg() {
		return this.oilStationImg;
	}

	public void setOilStationImg(String oilStationImg) {
		this.oilStationImg = oilStationImg;
	}

	public Short getOilStationImgDeleteFlag() {
		return this.oilStationImgDeleteFlag;
	}

	public void setOilStationImgDeleteFlag(Short oilStationImgDeleteFlag) {
		this.oilStationImgDeleteFlag = oilStationImgDeleteFlag;
	}

	public OilStationInfo getOilStationInfoTbl() {
		return this.oilStationInfoTbl;
	}

	public void setOilStationInfoTbl(OilStationInfo oilStationInfoTbl) {
		this.oilStationInfoTbl = oilStationInfoTbl;
	}

}