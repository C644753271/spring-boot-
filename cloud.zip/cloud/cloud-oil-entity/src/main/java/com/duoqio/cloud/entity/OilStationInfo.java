package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


/**
 * The persistent class for the oil_station_info_tbl database table.
 * 
 */
@Entity
@Table(name="oil_station_info_tbl")
@NamedEntityGraph(name = "OilStationInfo.lazy", attributeNodes = {@NamedAttributeNode("oilStationImgInfoTbls")})
public class OilStationInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="oil_station_id")
	private Integer oilStationId;

	@Column(name="oil_station_addr")
	private String oilStationAddr;

	@Column(name="oil_station_delete_flag")
	private Short oilStationDeleteFlag;

	@Column(name="oil_station_img")
	private String oilStationImg;

	@Column(name="oil_station_lat")
	private String oilStationLat;

	@Column(name="oil_station_long")
	private String oilStationLong;

	@Column(name="oil_station_name")
	private String oilStationName;

	//bi-directional many-to-one association to OilInfo
	@OneToMany(mappedBy="oilStationInfoTbl")
	@JsonIgnore
	private List<OilInfo> oilInfoTbls;

	//bi-directional many-to-one association to OilStationImgInfo
	@OneToMany(mappedBy="oilStationInfoTbl", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JsonIgnore
	private List<OilStationImgInfo> oilStationImgInfoTbls;

	public OilStationInfo() {
	}

	public Integer getOilStationId() {
		return this.oilStationId;
	}

	public void setOilStationId(Integer oilStationId) {
		this.oilStationId = oilStationId;
	}

	public String getOilStationAddr() {
		return this.oilStationAddr;
	}

	public void setOilStationAddr(String oilStationAddr) {
		this.oilStationAddr = oilStationAddr;
	}

	public Short getOilStationDeleteFlag() {
		return this.oilStationDeleteFlag;
	}

	public void setOilStationDeleteFlag(Short oilStationDeleteFlag) {
		this.oilStationDeleteFlag = oilStationDeleteFlag;
	}

	public String getOilStationImg() {
		return this.oilStationImg;
	}

	public void setOilStationImg(String oilStationImg) {
		this.oilStationImg = oilStationImg;
	}

	public String getOilStationLat() {
		return this.oilStationLat;
	}

	public void setOilStationLat(String oilStationLat) {
		this.oilStationLat = oilStationLat;
	}

	public String getOilStationLong() {
		return this.oilStationLong;
	}

	public void setOilStationLong(String oilStationLong) {
		this.oilStationLong = oilStationLong;
	}

	public String getOilStationName() {
		return this.oilStationName;
	}

	public void setOilStationName(String oilStationName) {
		this.oilStationName = oilStationName;
	}

	public List<OilInfo> getOilInfoTbls() {
		return this.oilInfoTbls;
	}

	public void setOilInfoTbls(List<OilInfo> oilInfoTbls) {
		this.oilInfoTbls = oilInfoTbls;
	}

	public OilInfo addOilInfoTbl(OilInfo oilInfoTbl) {
		getOilInfoTbls().add(oilInfoTbl);
		oilInfoTbl.setOilStationInfoTbl(this);

		return oilInfoTbl;
	}

	public OilInfo removeOilInfoTbl(OilInfo oilInfoTbl) {
		getOilInfoTbls().remove(oilInfoTbl);
		oilInfoTbl.setOilStationInfoTbl(null);

		return oilInfoTbl;
	}

	public List<OilStationImgInfo> getOilStationImgInfoTbls() {
		return this.oilStationImgInfoTbls;
	}

	public void setOilStationImgInfoTbls(List<OilStationImgInfo> oilStationImgInfoTbls) {
		this.oilStationImgInfoTbls = oilStationImgInfoTbls;
	}

	public OilStationImgInfo addOilStationImgInfoTbl(OilStationImgInfo oilStationImgInfoTbl) {
		getOilStationImgInfoTbls().add(oilStationImgInfoTbl);
		oilStationImgInfoTbl.setOilStationInfoTbl(this);

		return oilStationImgInfoTbl;
	}

	public OilStationImgInfo removeOilStationImgInfoTbl(OilStationImgInfo oilStationImgInfoTbl) {
		getOilStationImgInfoTbls().remove(oilStationImgInfoTbl);
		oilStationImgInfoTbl.setOilStationInfoTbl(null);

		return oilStationImgInfoTbl;
	}

}