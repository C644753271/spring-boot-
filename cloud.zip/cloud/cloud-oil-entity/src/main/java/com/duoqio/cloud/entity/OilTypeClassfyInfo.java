package com.duoqio.cloud.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.*;


@Entity
@Table(name="oil_type_classfy_info_tbl")
@NamedEntityGraph(name = "oilTypeClassfyInfoTbl.lazy", attributeNodes = {@NamedAttributeNode("oilTypeInfoTbls")})
public class OilTypeClassfyInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="oil_type_classfy_id")
	private Integer oilTypeClassfyId;
	
	@Column(name="oil_type_classfy_name")
	private String oilTypeClassfyName; 
	
	@Column(name="oil_type_classfy_delete_flag")
	private Short oilTypeClassfyDeleteFlag;
	
	@OneToMany(mappedBy="oilTypeClassfyInfoTbl", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	private List<OilTypeInfo> oilTypeInfoTbls;
	
	public OilTypeClassfyInfo() {
	}

	public Integer getOilTypeClassfyId() {
		return oilTypeClassfyId;
	}

	public void setOilTypeClassfyId(Integer oilTypeClassfyId) {
		this.oilTypeClassfyId = oilTypeClassfyId;
	}

	public String getOilTypeClassfyName() {
		return oilTypeClassfyName;
	}

	public void setOilTypeClassfyName(String oilTypeClassfyName) {
		this.oilTypeClassfyName = oilTypeClassfyName;
	}

	public Short getOilTypeClassfyDeleteFlag() {
		return oilTypeClassfyDeleteFlag;
	}

	public void setOilTypeClassfyDeleteFlag(Short oilTypeClassfyDeleteFlag) {
		this.oilTypeClassfyDeleteFlag = oilTypeClassfyDeleteFlag;
	}

	public List<OilTypeInfo> getOilTypeInfoTbls() {
		return oilTypeInfoTbls;
	}

	public void setOilTypeInfoTbls(List<OilTypeInfo> oilTypeInfoTbls) {
		this.oilTypeInfoTbls = oilTypeInfoTbls;
	}
	
	public OilTypeInfo addOilTypeInfoTbl(OilTypeInfo oilTypeInfoTbl) {
		getOilTypeInfoTbls().add(oilTypeInfoTbl);
		oilTypeInfoTbl.setOilTypeClassfyInfoTbl(this);
		return oilTypeInfoTbl;
	}
	
	public OilTypeInfo removeOilTypeInfoTbl(OilTypeInfo oilTypeInfoTbl) {
		getOilTypeInfoTbls().remove(oilTypeInfoTbl);
		oilTypeInfoTbl.setOilTypeClassfyInfoTbl(null);
		return oilTypeInfoTbl;
	}
	
}
