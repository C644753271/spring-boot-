package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


/**
 * The persistent class for the oil_type_info_tbl database table.
 * 
 */
@Entity
@Table(name="oil_type_info_tbl")
public class OilTypeInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="oil_type_id")
	private Integer oilTypeId;

	@Column(name="oil_type_delete_flag")
	private Short oilTypeDeleteFlag;

	@Column(name="oil_type_name")
	private String oilTypeName;
	
	//bi-directional many-to-one association to OilInfo
	@OneToMany(mappedBy="oilTypeInfoTbl")
	@JsonIgnore
	private List<OilInfo> oilInfoTbls;
	
	@OneToMany(mappedBy="oilTypeInfoTbl")
	@JsonIgnore
	private List<BatchOilInfo> batchOilInfoTbls;
	
	//bi-directional many-to-one association to OilTypeClassfyInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="oil_type_classfy_id")
	@JsonIgnore
	private OilTypeClassfyInfo oilTypeClassfyInfoTbl;

	public OilTypeInfo() {
	}

	public Integer getOilTypeId() {
		return this.oilTypeId;
	}

	public void setOilTypeId(Integer oilTypeId) {
		this.oilTypeId = oilTypeId;
	}

	public Short getOilTypeDeleteFlag() {
		return this.oilTypeDeleteFlag;
	}

	public void setOilTypeDeleteFlag(Short oilTypeDeleteFlag) {
		this.oilTypeDeleteFlag = oilTypeDeleteFlag;
	}

	public String getOilTypeName() {
		return this.oilTypeName;
	}

	public void setOilTypeName(String oilTypeName) {
		this.oilTypeName = oilTypeName;
	}

	public List<OilInfo> getOilInfoTbls() {
		return this.oilInfoTbls;
	}

	public void setOilInfoTbls(List<OilInfo> oilInfoTbls) {
		this.oilInfoTbls = oilInfoTbls;
	}

	public OilInfo addOilInfoTbl(OilInfo oilInfoTbl) {
		getOilInfoTbls().add(oilInfoTbl);
		oilInfoTbl.setOilTypeInfoTbl(this);

		return oilInfoTbl;
	}

	public OilInfo removeOilInfoTbl(OilInfo oilInfoTbl) {
		getOilInfoTbls().remove(oilInfoTbl);
		oilInfoTbl.setOilTypeInfoTbl(null);

		return oilInfoTbl;
	}
	
	public List<BatchOilInfo> getBatchOilInfoTbls() {
		return batchOilInfoTbls;
	}

	public void setBatchOilInfoTbls(List<BatchOilInfo> batchOilInfoTbls) {
		this.batchOilInfoTbls = batchOilInfoTbls;
	}
	
	public BatchOilInfo addBatchOilInfoTbl(BatchOilInfo batchOilInfoTbl) {
		getBatchOilInfoTbls().add(batchOilInfoTbl);
		batchOilInfoTbl.setOilTypeInfoTbl(this);

		return batchOilInfoTbl;
	}

	public BatchOilInfo removeBatchOilInfoTbl(BatchOilInfo batchOilInfoTbl) {
		getBatchOilInfoTbls().remove(batchOilInfoTbl);
		batchOilInfoTbl.setOilTypeInfoTbl(null);

		return batchOilInfoTbl;
	}

	public OilTypeClassfyInfo getOilTypeClassfyInfoTbl() {
		return oilTypeClassfyInfoTbl;
	}

	public void setOilTypeClassfyInfoTbl(OilTypeClassfyInfo oilTypeClassfyInfoTbl) {
		this.oilTypeClassfyInfoTbl = oilTypeClassfyInfoTbl;
	}
	
}