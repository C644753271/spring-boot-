package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the order_info_tbl database table.
 * 
 */
@Entity
@Table(name="order_info_tbl")
public class OrderInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="order_id")
	private Integer orderId;

	@Column(name="order_delete_flag")
	private Short orderDeleteFlag;

	@Column(name="order_delivery_status")
	private Short orderDeliveryStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="order_delivery_time")
	private Date orderDeliveryTime;

	@Column(name="order_evaluate_status")
	private Short orderEvaluateStatus;

	@Column(name="order_num")
	private Short orderNum;

	@Column(name="order_pay_type")
	private Short orderPayType;

	@Temporal(TemporalType.DATE)
	@Column(name="order_payment_time")
	private Date orderPaymentTime;

	@Column(name="order_price")
	private BigDecimal orderPrice;
	
	@Column(name="order_total_price")
	private BigDecimal orderTotalPrice;
	
	@Column(name="order_img")
	private String orderImg;

	@Column(name="order_product_name")
	private String orderProductName;

	@Column(name="order_shop_name")
	private String orderShopName;
	
	@Column(name="order_addr")
	private String orderAddr;
	
	@Column(name="post_type")
	private String postType;
	
	@Column(name="post_number")
	private String postNumber;

//	@Column(name="order_save_price")
//	private BigDecimal orderSavePrice;

	@Column(name="order_status")
	private Short orderStatus;

	@Column(name="order_take_delivery_status")
	private Short orderTakeDeliveryStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="order_time")
	private Date orderTime;

	@Column(name="order_tran_no")
	private String orderTranNo;

	@Column(name="order_transaction_id")
	private Integer orderTransactionId;

//	@Column(name="order_type")
//	private short orderType;

	//bi-directional many-to-one association to OilInfo
//	@OneToMany(mappedBy="orderInfoTbl")
//	private List<OilInfo> oilInfoTbls;

	//bi-directional many-to-one association to OilInfo
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="oil_id")
//	private OilInfo oilInfoTbl;

	//bi-directional many-to-one association to ProductInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="product_id")
	@JsonIgnore
	private ProductInfo productInfoTbl;

	//bi-directional many-to-one association to UserInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	@JsonIgnore
	private UserInfo userInfoTbl;

	//bi-directional many-to-one association to ProductInfo
//	@OneToMany(mappedBy="orderInfoTbl")
//	private List<ProductInfo> productInfoTbls;
	
	//bi-directional many-to-one association to ShopInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="shop_id")
	@JsonIgnore
	private ShopInfo shopInfoTbl;
	
	public OrderInfo() {
	}

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Short getOrderDeleteFlag() {
		return this.orderDeleteFlag;
	}

	public void setOrderDeleteFlag(Short orderDeleteFlag) {
		this.orderDeleteFlag = orderDeleteFlag;
	}

	public Short getOrderDeliveryStatus() {
		return this.orderDeliveryStatus;
	}

	public void setOrderDeliveryStatus(Short orderDeliveryStatus) {
		this.orderDeliveryStatus = orderDeliveryStatus;
	}

	public Date getOrderDeliveryTime() {
		return this.orderDeliveryTime;
	}

	public void setOrderDeliveryTime(Date orderDeliveryTime) {
		this.orderDeliveryTime = orderDeliveryTime;
	}

	public Short getOrderEvaluateStatus() {
		return this.orderEvaluateStatus;
	}

	public void setOrderEvaluateStatus(Short orderEvaluateStatus) {
		this.orderEvaluateStatus = orderEvaluateStatus;
	}

	public Short getOrderNum() {
		return this.orderNum;
	}

	public void setOrderNum(Short orderNum) {
		this.orderNum = orderNum;
	}

	public Short getOrderPayType() {
		return this.orderPayType;
	}

	public void setOrderPayType(Short orderPayType) {
		this.orderPayType = orderPayType;
	}

	public Date getOrderPaymentTime() {
		return this.orderPaymentTime;
	}

	public void setOrderPaymentTime(Date orderPaymentTime) {
		this.orderPaymentTime = orderPaymentTime;
	}

	public BigDecimal getOrderPrice() {
		return this.orderPrice;
	}

	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}

//	public BigDecimal getOrderSavePrice() {
//		return this.orderSavePrice;
//	}
//
//	public void setOrderSavePrice(BigDecimal orderSavePrice) {
//		this.orderSavePrice = orderSavePrice;
//	}

	public BigDecimal getOrderTotalPrice() {
		return orderTotalPrice;
	}

	public void setOrderTotalPrice(BigDecimal orderTotalPrice) {
		this.orderTotalPrice = orderTotalPrice;
	}

	public String getOrderImg() {
		return orderImg;
	}

	public void setOrderImg(String orderImg) {
		this.orderImg = orderImg;
	}

	public String getOrderProductName() {
		return orderProductName;
	}

	public void setOrderProductName(String orderProductName) {
		this.orderProductName = orderProductName;
	}

	public String getOrderShopName() {
		return orderShopName;
	}

	public void setOrderShopName(String orderShopName) {
		this.orderShopName = orderShopName;
	}
	
	public String getOrderAddr() {
		return orderAddr;
	}

	public void setOrderAddr(String orderAddr) {
		this.orderAddr = orderAddr;
	}

	public Short getOrderStatus() {
		return this.orderStatus;
	}

	public void setOrderStatus(Short orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Short getOrderTakeDeliveryStatus() {
		return this.orderTakeDeliveryStatus;
	}

	public void setOrderTakeDeliveryStatus(Short orderTakeDeliveryStatus) {
		this.orderTakeDeliveryStatus = orderTakeDeliveryStatus;
	}

	public Date getOrderTime() {
		return this.orderTime;
	}

	public void setOrderTime(Date orderTime) {
		this.orderTime = orderTime;
	}

	public String getOrderTranNo() {
		return this.orderTranNo;
	}

	public void setOrderTranNo(String orderTranNo) {
		this.orderTranNo = orderTranNo;
	}

	public Integer getOrderTransactionId() {
		return this.orderTransactionId;
	}

	public void setOrderTransactionId(Integer orderTransactionId) {
		this.orderTransactionId = orderTransactionId;
	}

//	public short getOrderType() {
//		return this.orderType;
//	}
//
//	public void setOrderType(short orderType) {
//		this.orderType = orderType;
//	}
//
//	public List<OilInfo> getOilInfoTbls() {
//		return this.oilInfoTbls;
//	}
//
//	public void setOilInfoTbls(List<OilInfo> oilInfoTbls) {
//		this.oilInfoTbls = oilInfoTbls;
//	}

//	public OilInfo addOilInfoTbl(OilInfo oilInfoTbl) {
//		getOilInfoTbls().add(oilInfoTbl);
//		oilInfoTbl.setOrderInfoTbl(this);
//
//		return oilInfoTbl;
//	}
//
//	public OilInfo removeOilInfoTbl(OilInfo oilInfoTbl) {
//		getOilInfoTbls().remove(oilInfoTbl);
//		oilInfoTbl.setOrderInfoTbl(null);
//
//		return oilInfoTbl;
//	}
//
//	public OilInfo getOilInfoTbl() {
//		return this.oilInfoTbl;
//	}
//
//	public void setOilInfoTbl(OilInfo oilInfoTbl) {
//		this.oilInfoTbl = oilInfoTbl;
//	}

	public ProductInfo getProductInfoTbl() {
		return this.productInfoTbl;
	}

	public void setProductInfoTbl(ProductInfo productInfoTbl) {
		this.productInfoTbl = productInfoTbl;
	}

	public UserInfo getUserInfoTbl() {
		return this.userInfoTbl;
	}

	public void setUserInfoTbl(UserInfo userInfoTbl) {
		this.userInfoTbl = userInfoTbl;
	}

	public ShopInfo getShopInfoTbl() {
		return shopInfoTbl;
	}

	public void setShopInfoTbl(ShopInfo shopInfoTbl) {
		this.shopInfoTbl = shopInfoTbl;
	}

	public String getPostType() {
		return postType;
	}

	public void setPostType(String postType) {
		this.postType = postType;
	}

	public String getPostNumber() {
		return postNumber;
	}

	public void setPostNumber(String postNumber) {
		this.postNumber = postNumber;
	}
	
//	public List<ProductInfo> getProductInfoTbls() {
//		return this.productInfoTbls;
//	}
//
//	public void setProductInfoTbls(List<ProductInfo> productInfoTbls) {
//		this.productInfoTbls = productInfoTbls;
//	}
//
//	public ProductInfo addProductInfoTbl(ProductInfo productInfoTbl) {
//		getProductInfoTbls().add(productInfoTbl);
//		productInfoTbl.setOrderInfoTbl(this);
//
//		return productInfoTbl;
//	}
//
//	public ProductInfo removeProductInfoTbl(ProductInfo productInfoTbl) {
//		getProductInfoTbls().remove(productInfoTbl);
//		productInfoTbl.setOrderInfoTbl(null);
//
//		return productInfoTbl;
//	}

}