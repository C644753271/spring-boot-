package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the product_img_info_tbl database table.
 * 
 */
@Entity
@Table(name="product_img_info_tbl")
public class ProductImgInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="product_img_id")
	private Integer productImgId;

	@Column(name="product_img")
	private String productImg;

	@Column(name="product_img_delete_flag")
	private Short productImgDeleteFlag;

	//bi-directional many-to-one association to ProductInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="product_id")
	@JsonIgnore
	private ProductInfo productInfoTbl;

	public ProductImgInfo() {
	}

	public Integer getProductImgId() {
		return this.productImgId;
	}

	public void setProductImgId(Integer productImgId) {
		this.productImgId = productImgId;
	}

	public String getProductImg() {
		return this.productImg;
	}

	public void setProductImg(String productImg) {
		this.productImg = productImg;
	}

	public Short getProductImgDeleteFlag() {
		return this.productImgDeleteFlag;
	}

	public void setProductImgDeleteFlag(Short productImgDeleteFlag) {
		this.productImgDeleteFlag = productImgDeleteFlag;
	}

	public ProductInfo getProductInfoTbl() {
		return this.productInfoTbl;
	}

	public void setProductInfoTbl(ProductInfo productInfoTbl) {
		this.productInfoTbl = productInfoTbl;
	}

}