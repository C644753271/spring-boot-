package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the product_info_tbl database table.
 * 
 */
@Entity
@Table(name="product_info_tbl")
@NamedEntityGraph(name = "ProductInfo.lazy", attributeNodes = {@NamedAttributeNode("productImgInfoTbls")})
public class ProductInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="product_id")
	private Integer productId;

	@Column(name="product_delete_flag")
	private Short productDeleteFlag;

	@Column(name="product_name")
	private String productName;
	
	@Column(name="product_img")
	private String productImg;

	@Column(name="product_order_count")
	private Integer productOrderCount;

	@Column(name="product_price")
	private BigDecimal productPrice;

	@Column(name="product_review")
	private Short productReview;
	
	@Column(name="review_status")
	private Short reviewStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="product_time")
	private Date productTime;

	//bi-directional many-to-one association to EvaluateInfo
	@OneToMany(mappedBy="productInfoTbl")
	@JsonIgnore
	private List<EvaluateInfo> evaluateInfoTbls;

	//bi-directional many-to-one association to OrderInfo
	@OneToMany(mappedBy="productInfoTbl")
	@JsonIgnore
	private List<OrderInfo> orderInfoTbls;

	//bi-directional many-to-one association to ProductImgInfo
	@OneToMany(mappedBy="productInfoTbl", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	private List<ProductImgInfo> productImgInfoTbls;

	//bi-directional many-to-one association to ClassifyInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="classify_id")
	@JsonIgnore
	private ClassifyInfo classifyInfoTbl;

	//bi-directional many-to-one association to OrderInfo
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="order_id")
//	private OrderInfo orderInfoTbl;

	//bi-directional many-to-one association to ShopInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="shop_id")
	@JsonIgnore
	private ShopInfo shopInfoTbl;

	public ProductInfo() {
	}

	public Integer getProductId() {
		return this.productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Short getProductDeleteFlag() {
		return this.productDeleteFlag;
	}

	public void setProductDeleteFlag(Short productDeleteFlag) {
		this.productDeleteFlag = productDeleteFlag;
	}

	public String getProductName() {
		return this.productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductImg() {
		return productImg;
	}

	public void setProductImg(String productImg) {
		this.productImg = productImg;
	}

	public Integer getProductOrderCount() {
		return this.productOrderCount;
	}

	public void setProductOrderCount(Integer productOrderCount) {
		this.productOrderCount = productOrderCount;
	}

	public BigDecimal getProductPrice() {
		return this.productPrice;
	}

	public void setProductPrice(BigDecimal productPrice) {
		this.productPrice = productPrice;
	}

	public Short getProductReview() {
		return this.productReview;
	}

	public void setProductReview(Short productReview) {
		this.productReview = productReview;
	}

	public Short getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(Short reviewStatus) {
		this.reviewStatus = reviewStatus;
	}

	public Date getProductTime() {
		return this.productTime;
	}

	public void setProductTime(Date productTime) {
		this.productTime = productTime;
	}

	public List<EvaluateInfo> getEvaluateInfoTbls() {
		return this.evaluateInfoTbls;
	}

	public void setEvaluateInfoTbls(List<EvaluateInfo> evaluateInfoTbls) {
		this.evaluateInfoTbls = evaluateInfoTbls;
	}

	public EvaluateInfo addEvaluateInfoTbl(EvaluateInfo evaluateInfoTbl) {
		getEvaluateInfoTbls().add(evaluateInfoTbl);
		evaluateInfoTbl.setProductInfoTbl(this);

		return evaluateInfoTbl;
	}

	public EvaluateInfo removeEvaluateInfoTbl(EvaluateInfo evaluateInfoTbl) {
		getEvaluateInfoTbls().remove(evaluateInfoTbl);
		evaluateInfoTbl.setProductInfoTbl(null);

		return evaluateInfoTbl;
	}

	public List<OrderInfo> getOrderInfoTbls() {
		return this.orderInfoTbls;
	}

	public void setOrderInfoTbls(List<OrderInfo> orderInfoTbls) {
		this.orderInfoTbls = orderInfoTbls;
	}

	public OrderInfo addOrderInfoTbl(OrderInfo orderInfoTbl) {
		getOrderInfoTbls().add(orderInfoTbl);
		orderInfoTbl.setProductInfoTbl(this);

		return orderInfoTbl;
	}

	public OrderInfo removeOrderInfoTbl(OrderInfo orderInfoTbl) {
		getOrderInfoTbls().remove(orderInfoTbl);
		orderInfoTbl.setProductInfoTbl(null);

		return orderInfoTbl;
	}

	public List<ProductImgInfo> getProductImgInfoTbls() {
		return this.productImgInfoTbls;
	}

	public void setProductImgInfoTbls(List<ProductImgInfo> productImgInfoTbls) {
		this.productImgInfoTbls = productImgInfoTbls;
	}

	public ProductImgInfo addProductImgInfoTbl(ProductImgInfo productImgInfoTbl) {
		getProductImgInfoTbls().add(productImgInfoTbl);
		productImgInfoTbl.setProductInfoTbl(this);

		return productImgInfoTbl;
	}

	public ProductImgInfo removeProductImgInfoTbl(ProductImgInfo productImgInfoTbl) {
		getProductImgInfoTbls().remove(productImgInfoTbl);
		productImgInfoTbl.setProductInfoTbl(null);

		return productImgInfoTbl;
	}

	public ClassifyInfo getClassifyInfoTbl() {
		return this.classifyInfoTbl;
	}

	public void setClassifyInfoTbl(ClassifyInfo classifyInfoTbl) {
		this.classifyInfoTbl = classifyInfoTbl;
	}

//	public OrderInfo getOrderInfoTbl() {
//		return this.orderInfoTbl;
//	}
//
//	public void setOrderInfoTbl(OrderInfo orderInfoTbl) {
//		this.orderInfoTbl = orderInfoTbl;
//	}

	public ShopInfo getShopInfoTbl() {
		return this.shopInfoTbl;
	}

	public void setShopInfoTbl(ShopInfo shopInfoTbl) {
		this.shopInfoTbl = shopInfoTbl;
	}

}