package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.util.List;


/**
 * The persistent class for the role_info_tbl database table.
 * 
 */
@Entity
@Table(name="role_info_tbl")
//@NamedEntityGraph(name = "RoleInfo.lazy", attributeNodes = {@NamedAttributeNode("roleMenuInfoTbls")})
public class RoleInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="role_id")
	private Integer roleId;

	@Column(name="role_delete_flag")
	private Short roleDeleteFlag;

	@Column(name="role_name")
	private String roleName;

//	//bi-directional many-to-one association to UserInfo
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="user_id")
//	private UserInfo userInfoTbl;

	//bi-directional many-to-one association to RoleMenuInfo
	@OneToMany(mappedBy="roleInfoTbl")
	private List<RoleMenuInfo> roleMenuInfoTbls;

	//bi-directional many-to-one association to UserInfo
	@OneToMany(mappedBy="roleInfoTbl")
	private List<UserInfo> userInfoTbls;

	public RoleInfo() {
	}

	public Integer getRoleId() {
		return this.roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public Short getRoleDeleteFlag() {
		return this.roleDeleteFlag;
	}

	public void setRoleDeleteFlag(Short roleDeleteFlag) {
		this.roleDeleteFlag = roleDeleteFlag;
	}

	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

//	public UserInfo getUserInfoTbl() {
//		return this.userInfoTbl;
//	}
//
//	public void setUserInfoTbl(UserInfo userInfoTbl) {
//		this.userInfoTbl = userInfoTbl;
//	}

	public List<RoleMenuInfo> getRoleMenuInfoTbls() {
		return this.roleMenuInfoTbls;
	}

	public void setRoleMenuInfoTbls(List<RoleMenuInfo> roleMenuInfoTbls) {
		this.roleMenuInfoTbls = roleMenuInfoTbls;
	}

	public RoleMenuInfo addRoleMenuInfoTbl(RoleMenuInfo roleMenuInfoTbl) {
		getRoleMenuInfoTbls().add(roleMenuInfoTbl);
		roleMenuInfoTbl.setRoleInfoTbl(this);

		return roleMenuInfoTbl;
	}

	public RoleMenuInfo removeRoleMenuInfoTbl(RoleMenuInfo roleMenuInfoTbl) {
		getRoleMenuInfoTbls().remove(roleMenuInfoTbl);
		roleMenuInfoTbl.setRoleInfoTbl(null);

		return roleMenuInfoTbl;
	}

	public List<UserInfo> getUserInfoTbls() {
		return this.userInfoTbls;
	}

	public void setUserInfoTbls(List<UserInfo> userInfoTbls) {
		this.userInfoTbls = userInfoTbls;
	}

	public UserInfo addUserInfoTbl(UserInfo userInfoTbl) {
		getUserInfoTbls().add(userInfoTbl);
		userInfoTbl.setRoleInfoTbl(this);

		return userInfoTbl;
	}

	public UserInfo removeUserInfoTbl(UserInfo userInfoTbl) {
		getUserInfoTbls().remove(userInfoTbl);
		userInfoTbl.setRoleInfoTbl(null);

		return userInfoTbl;
	}

}