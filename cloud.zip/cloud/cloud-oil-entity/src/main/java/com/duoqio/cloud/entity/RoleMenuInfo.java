package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the role_menu_info_tbl database table.
 * 
 */
@Entity
@Table(name="role_menu_info_tbl")
@NamedEntityGraph(name = "RoleMenuInfo.lazy", attributeNodes = {@NamedAttributeNode("menuInfoTbl")})
public class RoleMenuInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="role_menu_id")
	private Integer roleMenuId;

	//bi-directional many-to-one association to RoleInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="role_id")
	@JsonIgnore
	private RoleInfo roleInfoTbl;

	//bi-directional many-to-one association to MenuInfoTbl
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="menu_id")
	private MenuInfoTbl menuInfoTbl;
	
	@Column(name="delete_flag")
	private Short deleteFlag;

	public RoleMenuInfo() {
	}

	public Integer getRoleMenuId() {
		return this.roleMenuId;
	}

	public void setRoleMenuId(Integer roleMenuId) {
		this.roleMenuId = roleMenuId;
	}

	public RoleInfo getRoleInfoTbl() {
		return this.roleInfoTbl;
	}

	public void setRoleInfoTbl(RoleInfo roleInfoTbl) {
		this.roleInfoTbl = roleInfoTbl;
	}

	public MenuInfoTbl getMenuInfoTbl() {
		return this.menuInfoTbl;
	}

	public void setMenuInfoTbl(MenuInfoTbl menuInfoTbl) {
		this.menuInfoTbl = menuInfoTbl;
	}

	public Short getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(Short deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
}