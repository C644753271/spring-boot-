package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the shop_img_info_tbl database table.
 * 
 */
@Entity
@Table(name="shop_img_info_tbl")
public class ShopImgInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="shop_img_id")
	private Integer shopImgId;

	@Column(name="shop_img")
	private String shopImg;

	@Column(name="shop_img_delete_flag")
	private Short shopImgDeleteFlag;

	//bi-directional many-to-one association to ShopInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="shop_id")
	@JsonIgnore
	private ShopInfo shopInfoTbl;

	public ShopImgInfo() {
	}

	public Integer getShopImgId() {
		return this.shopImgId;
	}

	public void setShopImgId(Integer shopImgId) {
		this.shopImgId = shopImgId;
	}

	public String getShopImg() {
		return this.shopImg;
	}

	public void setShopImg(String shopImg) {
		this.shopImg = shopImg;
	}

	public Short getShopImgDeleteFlag() {
		return this.shopImgDeleteFlag;
	}

	public void setShopImgDeleteFlag(Short shopImgDeleteFlag) {
		this.shopImgDeleteFlag = shopImgDeleteFlag;
	}

	public ShopInfo getShopInfoTbl() {
		return this.shopInfoTbl;
	}

	public void setShopInfoTbl(ShopInfo shopInfoTbl) {
		this.shopInfoTbl = shopInfoTbl;
	}

}