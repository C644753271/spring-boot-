package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


/**
 * The persistent class for the shop_info_tbl database table.
 * 
 */
@Entity
@Table(name="shop_info_tbl")
@NamedEntityGraph(name = "ShopInfo.lazy", attributeNodes = {@NamedAttributeNode("shopImgInfoTbls")})
public class ShopInfo implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="shop_id")
	private Integer shopId;

	@Column(name="shop_addr")
	private String shopAddr;

	@Column(name="shop_delete_flag")
	private Short shopDeleteFlag;

	@Column(name="shop_introduce")
	private String shopIntroduce;

	@Column(name="shop_lat")
	private String shopLat;

	@Column(name="shop_long")
	private String shopLong;

	@Column(name="shop_name")
	private String shopName;
	
	@Column(name="shop_img")
	private String shopImg;

	@Column(name="shop_tel")
	private String shopTel;
	
	//bi-directional many-to-one association to ProductI nfo
	@OneToMany(mappedBy="shopInfoTbl")
	@JsonIgnore
	private List<ProductInfo> productInfoTbls;

	//bi-directional many-to-one association to ShopImgInfo
	@OneToMany(mappedBy="shopInfoTbl", cascade = {CascadeType.ALL})
	private List<ShopImgInfo> shopImgInfoTbls;
	
	//bi-directional many-to-one association to ShopImgInfo
	@OneToMany(mappedBy="shopInfoTbl")
	@JsonIgnore
	private List<OrderInfo> orderInfoTbls;

	//bi-directional many-to-one association to UserInfo
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	@JsonIgnore
	private UserInfo userInfoTbl;

	//bi-directional many-to-one association to UserInfo
//	@OneToMany(mappedBy="shopInfoTbl")
//	private List<UserInfo> userInfoTbls;

	public ShopInfo() {
	}

	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public String getShopAddr() {
		return this.shopAddr;
	}

	public void setShopAddr(String shopAddr) {
		this.shopAddr = shopAddr;
	}

	public Short getShopDeleteFlag() {
		return this.shopDeleteFlag;
	}

	public void setShopDeleteFlag(Short shopDeleteFlag) {
		this.shopDeleteFlag = shopDeleteFlag;
	}

	public String getShopIntroduce() {
		return this.shopIntroduce;
	}

	public void setShopIntroduce(String shopIntroduce) {
		this.shopIntroduce = shopIntroduce;
	}

	public String getShopLat() {
		return this.shopLat;
	}

	public void setShopLat(String shopLat) {
		this.shopLat = shopLat;
	}

	public String getShopLong() {
		return this.shopLong;
	}

	public void setShopLong(String shopLong) {
		this.shopLong = shopLong;
	}

	public String getShopName() {
		return this.shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopImg() {
		return shopImg;
	}

	public void setShopImg(String shopImg) {
		this.shopImg = shopImg;
	}

	public String getShopTel() {
		return this.shopTel;
	}

	public void setShopTel(String shopTel) {
		this.shopTel = shopTel;
	}

	public List<ProductInfo> getProductInfoTbls() {
		return this.productInfoTbls;
	}

	public void setProductInfoTbls(List<ProductInfo> productInfoTbls) {
		this.productInfoTbls = productInfoTbls;
	}

	public ProductInfo addProductInfoTbl(ProductInfo productInfoTbl) {
		getProductInfoTbls().add(productInfoTbl);
		productInfoTbl.setShopInfoTbl(this);

		return productInfoTbl;
	}

	public ProductInfo removeProductInfoTbl(ProductInfo productInfoTbl) {
		getProductInfoTbls().remove(productInfoTbl);
		productInfoTbl.setShopInfoTbl(null);

		return productInfoTbl;
	}

	public List<ShopImgInfo> getShopImgInfoTbls() {
		return this.shopImgInfoTbls;
	}

	public void setShopImgInfoTbls(List<ShopImgInfo> shopImgInfoTbls) {
		this.shopImgInfoTbls = shopImgInfoTbls;
	}

	public ShopImgInfo addShopImgInfoTbl(ShopImgInfo shopImgInfoTbl) {
		getShopImgInfoTbls().add(shopImgInfoTbl);
		shopImgInfoTbl.setShopInfoTbl(this);

		return shopImgInfoTbl;
	}

	public ShopImgInfo removeShopImgInfoTbl(ShopImgInfo shopImgInfoTbl) {
		getShopImgInfoTbls().remove(shopImgInfoTbl);
		shopImgInfoTbl.setShopInfoTbl(null);

		return shopImgInfoTbl;
	}
	
	public List<OrderInfo> getOrderInfoTbls() {
		return this.orderInfoTbls;
	}

	public void setOrderInfoTbls(List<OrderInfo> orderInfoTbls) {
		this.orderInfoTbls = orderInfoTbls;
	}

	public OrderInfo addOrderInfoTbl(OrderInfo orderInfoTbl) {
		getOrderInfoTbls().add(orderInfoTbl);
		orderInfoTbl.setShopInfoTbl(this);

		return orderInfoTbl;
	}

	public OrderInfo removeOrderInfoTbl(OrderInfo orderInfoTbl) {
		getOrderInfoTbls().remove(orderInfoTbl);
		orderInfoTbl.setShopInfoTbl(null);

		return orderInfoTbl;
	}

	public UserInfo getUserInfoTbl() {
		return this.userInfoTbl;
	}

	public void setUserInfoTbl(UserInfo userInfoTbl) {
		this.userInfoTbl = userInfoTbl;
	}

//	public List<UserInfo> getUserInfoTbls() {
//		return this.userInfoTbls;
//	}
//
//	public void setUserInfoTbls(List<UserInfo> userInfoTbls) {
//		this.userInfoTbls = userInfoTbls;
//	}
//
//	public UserInfo addUserInfoTbl(UserInfo userInfoTbl) {
//		getUserInfoTbls().add(userInfoTbl);
//		userInfoTbl.setShopInfoTbl(this);
//
//		return userInfoTbl;
//	}
//
//	public UserInfo removeUserInfoTbl(UserInfo userInfoTbl) {
//		getUserInfoTbls().remove(userInfoTbl);
//		userInfoTbl.setShopInfoTbl(null);
//
//		return userInfoTbl;
//	}

}