package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the stage_car_appointment_info_tbl database table.
 * 
 */
@Entity
@Table(name="stage_car_appointment_info_tbl")
public class StageCarAppointmentInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="appointment_id")
	private Integer appointmentId;

	@Column(name="appointment_name")
	private String appointmentName;

	@Column(name="appointment_status")
	private short appointmentStatus;

	@Column(name="appointment_tel")
	private String appointmentTel;

	@Temporal(TemporalType.DATE)
	@Column(name="appointment_time")
	private Date appointmentTime;

	//bi-directional many-to-one association to UserInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	private UserInfo userInfoTbl;

	//bi-directional many-to-one association to StageCarInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="stage_car_id")
	private StageCarInfo stageCarInfoTbl;

	public StageCarAppointmentInfo() {
	}

	public Integer getAppointmentId() {
		return this.appointmentId;
	}

	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getAppointmentName() {
		return this.appointmentName;
	}

	public void setAppointmentName(String appointmentName) {
		this.appointmentName = appointmentName;
	}

	public short getAppointmentStatus() {
		return this.appointmentStatus;
	}

	public void setAppointmentStatus(short appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}

	public String getAppointmentTel() {
		return this.appointmentTel;
	}

	public void setAppointmentTel(String appointmentTel) {
		this.appointmentTel = appointmentTel;
	}

	public Date getAppointmentTime() {
		return this.appointmentTime;
	}

	public void setAppointmentTime(Date appointmentTime) {
		this.appointmentTime = appointmentTime;
	}

	public UserInfo getUserInfoTbl() {
		return this.userInfoTbl;
	}

	public void setUserInfoTbl(UserInfo userInfoTbl) {
		this.userInfoTbl = userInfoTbl;
	}

	public StageCarInfo getStageCarInfoTbl() {
		return this.stageCarInfoTbl;
	}

	public void setStageCarInfoTbl(StageCarInfo stageCarInfoTbl) {
		this.stageCarInfoTbl = stageCarInfoTbl;
	}

}