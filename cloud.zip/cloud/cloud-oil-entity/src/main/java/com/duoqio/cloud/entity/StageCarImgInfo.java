package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the stage_car_img_info_tbl database table.
 * 
 */
@Entity
@Table(name="stage_car_img_info_tbl")
public class StageCarImgInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="stage_car_img_id")
	private Integer stageCarImgId;

	@Column(name="stage_car_img")
	private String stageCarImg;

	@Column(name="stage_car_img_deleteflag")
	private Short stageCarImgDeleteflag;

	//bi-directional many-to-one association to StageCarInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="stage_car_id")
	@JsonIgnore
	private StageCarInfo stageCarInfoTbl;

	public StageCarImgInfo() {
	}

	public Integer getStageCarImgId() {
		return this.stageCarImgId;
	}

	public void setStageCarImgId(Integer stageCarImgId) {
		this.stageCarImgId = stageCarImgId;
	}

	public String getStageCarImg() {
		return this.stageCarImg;
	}

	public void setStageCarImg(String stageCarImg) {
		this.stageCarImg = stageCarImg;
	}

	public Short getStageCarImgDeleteflag() {
		return this.stageCarImgDeleteflag;
	}

	public void setStageCarImgDeleteflag(Short stageCarImgDeleteflag) {
		this.stageCarImgDeleteflag = stageCarImgDeleteflag;
	}

	public StageCarInfo getStageCarInfoTbl() {
		return this.stageCarInfoTbl;
	}

	public void setStageCarInfoTbl(StageCarInfo stageCarInfoTbl) {
		this.stageCarInfoTbl = stageCarInfoTbl;
	}

}