package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the stage_car_info_tbl database table.
 * 
 */
@Entity
@Table(name="stage_car_info_tbl")
@NamedEntityGraph(name = "StageCarInfo.lazy", attributeNodes = {@NamedAttributeNode("stageCarImgInfoTbls")})
public class StageCarInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="stage_car_id")
	private Integer stageCarId;

	@Lob
	@Column(name="stage_car_basicparam")
	private String stageCarBasicparam;

	@Lob
	@Column(name="stage_car_bodyparam")
	private String stageCarBodyparam;

	@Lob
	@Column(name="stage_car_brakeparam")
	private String stageCarBrakeparam;

	@Column(name="stage_car_count")
	private Short stageCarCount;

	@Column(name="stage_car_divideprice")
	private BigDecimal stageCarDivideprice;

	@Lob
	@Column(name="stage_car_engineparam")
	private String stageCarEngineparam;

	@Column(name="stage_car_name")
	private String stageCarName;
	
	@Column(name="stage_car_detail")
	private String stageCarDetail;

	@Column(name="stage_car_price")
	private BigDecimal stageCarPrice;
	
	@Column(name="guide_price")
	private BigDecimal guidePrice;

	@Lob
	@Column(name="stage_car_steerparam")
	private String stageCarSteerparam;

	@Temporal(TemporalType.DATE)
	@Column(name="stage_car_time")
	private Date stageCarTime;

	@Lob
	@Column(name="stage_car_transmissionparam")
	private String stageCarTransmissionparam;

	@Column(name="stage_cat_deleteflag")
	private Short stageCatDeleteflag;

	//bi-directional many-to-one association to StageCarAppointmentInfo
	@OneToMany(mappedBy="stageCarInfoTbl")
	@JsonIgnore
	private List<StageCarAppointmentInfo> stageCarAppointmentInfoTbls;

	//bi-directional many-to-one association to StageCarImgInfo
	@OneToMany(mappedBy="stageCarInfoTbl", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	private List<StageCarImgInfo> stageCarImgInfoTbls;

	public StageCarInfo() {
	}

	public Integer getStageCarId() {
		return this.stageCarId;
	}

	public void setStageCarId(Integer stageCarId) {
		this.stageCarId = stageCarId;
	}

	public String getStageCarBasicparam() {
		return this.stageCarBasicparam;
	}

	public void setStageCarBasicparam(String stageCarBasicparam) {
		this.stageCarBasicparam = stageCarBasicparam;
	}

	public String getStageCarBodyparam() {
		return this.stageCarBodyparam;
	}

	public void setStageCarBodyparam(String stageCarBodyparam) {
		this.stageCarBodyparam = stageCarBodyparam;
	}

	public String getStageCarBrakeparam() {
		return this.stageCarBrakeparam;
	}

	public void setStageCarBrakeparam(String stageCarBrakeparam) {
		this.stageCarBrakeparam = stageCarBrakeparam;
	}

	public Short getStageCarCount() {
		return this.stageCarCount;
	}

	public void setStageCarCount(Short stageCarCount) {
		this.stageCarCount = stageCarCount;
	}

	public BigDecimal getStageCarDivideprice() {
		return this.stageCarDivideprice;
	}

	public void setStageCarDivideprice(BigDecimal stageCarDivideprice) {
		this.stageCarDivideprice = stageCarDivideprice;
	}

	public String getStageCarEngineparam() {
		return this.stageCarEngineparam;
	}

	public void setStageCarEngineparam(String stageCarEngineparam) {
		this.stageCarEngineparam = stageCarEngineparam;
	}

	public String getStageCarName() {
		return this.stageCarName;
	}

	public void setStageCarName(String stageCarName) {
		this.stageCarName = stageCarName;
	}

	public BigDecimal getStageCarPrice() {
		return this.stageCarPrice;
	}

	public void setStageCarPrice(BigDecimal stageCarPrice) {
		this.stageCarPrice = stageCarPrice;
	}

	public String getStageCarSteerparam() {
		return this.stageCarSteerparam;
	}

	public void setStageCarSteerparam(String stageCarSteerparam) {
		this.stageCarSteerparam = stageCarSteerparam;
	}

	public Date getStageCarTime() {
		return this.stageCarTime;
	}

	public void setStageCarTime(Date stageCarTime) {
		this.stageCarTime = stageCarTime;
	}

	public String getStageCarTransmissionparam() {
		return this.stageCarTransmissionparam;
	}

	public void setStageCarTransmissionparam(String stageCarTransmissionparam) {
		this.stageCarTransmissionparam = stageCarTransmissionparam;
	}

	public Short getStageCatDeleteflag() {
		return this.stageCatDeleteflag;
	}

	public void setStageCatDeleteflag(Short stageCatDeleteflag) {
		this.stageCatDeleteflag = stageCatDeleteflag;
	}

	public List<StageCarAppointmentInfo> getStageCarAppointmentInfoTbls() {
		return this.stageCarAppointmentInfoTbls;
	}

	public void setStageCarAppointmentInfoTbls(List<StageCarAppointmentInfo> stageCarAppointmentInfoTbls) {
		this.stageCarAppointmentInfoTbls = stageCarAppointmentInfoTbls;
	}

	public StageCarAppointmentInfo addStageCarAppointmentInfoTbl(StageCarAppointmentInfo stageCarAppointmentInfoTbl) {
		getStageCarAppointmentInfoTbls().add(stageCarAppointmentInfoTbl);
		stageCarAppointmentInfoTbl.setStageCarInfoTbl(this);

		return stageCarAppointmentInfoTbl;
	}

	public StageCarAppointmentInfo removeStageCarAppointmentInfoTbl(StageCarAppointmentInfo stageCarAppointmentInfoTbl) {
		getStageCarAppointmentInfoTbls().remove(stageCarAppointmentInfoTbl);
		stageCarAppointmentInfoTbl.setStageCarInfoTbl(null);

		return stageCarAppointmentInfoTbl;
	}

	public List<StageCarImgInfo> getStageCarImgInfoTbls() {
		return this.stageCarImgInfoTbls;
	}

	public void setStageCarImgInfoTbls(List<StageCarImgInfo> stageCarImgInfoTbls) {
		this.stageCarImgInfoTbls = stageCarImgInfoTbls;
	}

	public StageCarImgInfo addStageCarImgInfoTbl(StageCarImgInfo stageCarImgInfoTbl) {
		getStageCarImgInfoTbls().add(stageCarImgInfoTbl);
		stageCarImgInfoTbl.setStageCarInfoTbl(this);

		return stageCarImgInfoTbl;
	}

	public StageCarImgInfo removeStageCarImgInfoTbl(StageCarImgInfo stageCarImgInfoTbl) {
		getStageCarImgInfoTbls().remove(stageCarImgInfoTbl);
		stageCarImgInfoTbl.setStageCarInfoTbl(null);

		return stageCarImgInfoTbl;
	}

	public String getStageCarDetail() {
		return stageCarDetail;
	}

	public void setStageCarDetail(String stageCarDetail) {
		this.stageCarDetail = stageCarDetail;
	}

	public BigDecimal getGuidePrice() {
		return guidePrice;
	}

	public void setGuidePrice(BigDecimal guidePrice) {
		this.guidePrice = guidePrice;
	}

}