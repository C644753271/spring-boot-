package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the user_info_tbl database table.
 * 
 */
@Entity
@Table(name="user_info_tbl")
@NamedEntityGraph(name = "UserInfo.lazy", attributeNodes = {@NamedAttributeNode("oilCardInfoTbls")})
public class UserInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="user_id")
	private Integer userId;

	@Column(name="user_account")
	private String userAccount;

	@Temporal(TemporalType.DATE)
	@Column(name="user_add_time")
	private Date userAddTime;

	@Column(name="user_delete_flag")
	private Short userDeleteFlag;

	@Column(name="user_img")
	private String userImg;

	@Column(name="user_nickname")
	private String userNickname;

	@Column(name="user_p_id")
	private Integer userPId;

	@Column(name="user_p_id_str")
	private String userPIdStr;

	@Column(name="user_password")
	private String userPassword;

	@Column(name="user_qr_code")
	private String userQrCode;

	@Column(name="user_tel")
	private String userTel;
	
	@Column(name="vip_flag")
	private Short vipFlag;

	//bi-directional many-to-one association to AddressInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<AddressInfo> addressInfoTbls;

	//bi-directional many-to-one association to ApplyOilCardInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<ApplyOilCardInfo> applyOilCardInfoTbls;

	//bi-directional many-to-one association to BusinessInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<BusinessInfo> businessInfoTbls;

	//bi-directional many-to-one association to DistributionInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<DistributionInfo> distributionInfoTbls;

	//bi-directional many-to-one association to EvaluateInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<EvaluateInfo> evaluateInfoTbls;

	//bi-directional many-to-one association to MessageInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<MessageInfo> messageInfoTbls;

	//bi-directional many-to-one association to OilCardInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<OilCardInfo> oilCardInfoTbls;

	//bi-directional many-to-one association to OrderInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<OrderInfo> orderInfoTbls;
	
	//bi-directional many-to-one association to OilOrderInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<OilOrderInfo> oilOrderInfoTbls;

	//bi-directional many-to-one association to ShopInfo
//	@OneToMany(mappedBy="userInfoTbl")
//	private List<ShopInfo> shopInfoTbls;

	//bi-directional many-to-one association to ShopInfo
//	@OneToOne(fetch=FetchType.LAZY)
//	private ShopInfo shopInfoTbl;

//	//bi-directional many-to-one association to RoleInfo
//	@OneToMany(mappedBy="userInfoTbl")
//	private List<RoleInfo> roleInfoTbls;

	//bi-directional many-to-one association to RoleInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="role_id")
	@JsonIgnore
	private RoleInfo roleInfoTbl;
	
	//bi-directional many-to-one association to StageCarAppointmentInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<StageCarAppointmentInfo> stageCarAppointmentInfoTbls;
	
	//bi-directional many-to-one association to VipOrderInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<VipOrderInfo> vipOrderInfoTbls;
	
	//bi-directional many-to-one association to MoneyInfo
	@OneToMany(mappedBy="userInfoTbl")
	@JsonIgnore
	private List<MoneyInfo> moneyInfoTbls;

	public UserInfo() {
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserAccount() {
		return this.userAccount;
	}

	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}

	public Date getUserAddTime() {
		return this.userAddTime;
	}

	public void setUserAddTime(Date userAddTime) {
		this.userAddTime = userAddTime;
	}

	public Short getUserDeleteFlag() {
		return this.userDeleteFlag;
	}

	public void setUserDeleteFlag(Short userDeleteFlag) {
		this.userDeleteFlag = userDeleteFlag;
	}

	public String getUserImg() {
		return this.userImg;
	}

	public void setUserImg(String userImg) {
		this.userImg = userImg;
	}

	public String getUserNickname() {
		return this.userNickname;
	}

	public void setUserNickname(String userNickname) {
		this.userNickname = userNickname;
	}

	public Integer getUserPId() {
		return this.userPId;
	}

	public void setUserPId(Integer userPId) {
		this.userPId = userPId;
	}

	public String getUserPIdStr() {
		return this.userPIdStr;
	}

	public void setUserPIdStr(String userPIdStr) {
		this.userPIdStr = userPIdStr;
	}

	public String getUserPassword() {
		return this.userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserQrCode() {
		return this.userQrCode;
	}

	public void setUserQrCode(String userQrCode) {
		this.userQrCode = userQrCode;
	}

	public String getUserTel() {
		return this.userTel;
	}

	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}
	
	public Short getVipFlag() {
		return vipFlag;
	}

	public void setVipFlag(Short vipFlag) {
		this.vipFlag = vipFlag;
	}

	public List<AddressInfo> getAddressInfoTbls() {
		return this.addressInfoTbls;
	}

	public void setAddressInfoTbls(List<AddressInfo> addressInfoTbls) {
		this.addressInfoTbls = addressInfoTbls;
	}

	public AddressInfo addAddressInfoTbl(AddressInfo addressInfoTbl) {
		getAddressInfoTbls().add(addressInfoTbl);
		addressInfoTbl.setUserInfoTbl(this);

		return addressInfoTbl;
	}

	public AddressInfo removeAddressInfoTbl(AddressInfo addressInfoTbl) {
		getAddressInfoTbls().remove(addressInfoTbl);
		addressInfoTbl.setUserInfoTbl(null);

		return addressInfoTbl;
	}

	public List<ApplyOilCardInfo> getApplyOilCardInfoTbls() {
		return this.applyOilCardInfoTbls;
	}

	public void setApplyOilCardInfoTbls(List<ApplyOilCardInfo> applyOilCardInfoTbls) {
		this.applyOilCardInfoTbls = applyOilCardInfoTbls;
	}

	public ApplyOilCardInfo addApplyOilCardInfoTbl(ApplyOilCardInfo applyOilCardInfoTbl) {
		getApplyOilCardInfoTbls().add(applyOilCardInfoTbl);
		applyOilCardInfoTbl.setUserInfoTbl(this);

		return applyOilCardInfoTbl;
	}

	public ApplyOilCardInfo removeApplyOilCardInfoTbl(ApplyOilCardInfo applyOilCardInfoTbl) {
		getApplyOilCardInfoTbls().remove(applyOilCardInfoTbl);
		applyOilCardInfoTbl.setUserInfoTbl(null);

		return applyOilCardInfoTbl;
	}

	public List<BusinessInfo> getBusinessInfoTbls() {
		return this.businessInfoTbls;
	}

	public void setBusinessInfoTbls(List<BusinessInfo> businessInfoTbls) {
		this.businessInfoTbls = businessInfoTbls;
	}

	public BusinessInfo addBusinessInfoTbl(BusinessInfo businessInfoTbl) {
		getBusinessInfoTbls().add(businessInfoTbl);
		businessInfoTbl.setUserInfoTbl(this);

		return businessInfoTbl;
	}

	public BusinessInfo removeBusinessInfoTbl(BusinessInfo businessInfoTbl) {
		getBusinessInfoTbls().remove(businessInfoTbl);
		businessInfoTbl.setUserInfoTbl(null);

		return businessInfoTbl;
	}

	public List<DistributionInfo> getDistributionInfoTbls() {
		return this.distributionInfoTbls;
	}

	public void setDistributionInfoTbls(List<DistributionInfo> distributionInfoTbls) {
		this.distributionInfoTbls = distributionInfoTbls;
	}

	public DistributionInfo addDistributionInfoTbl(DistributionInfo distributionInfoTbl) {
		getDistributionInfoTbls().add(distributionInfoTbl);
		distributionInfoTbl.setUserInfoTbl(this);

		return distributionInfoTbl;
	}

	public DistributionInfo removeDistributionInfoTbl(DistributionInfo distributionInfoTbl) {
		getDistributionInfoTbls().remove(distributionInfoTbl);
		distributionInfoTbl.setUserInfoTbl(null);

		return distributionInfoTbl;
	}

	public List<EvaluateInfo> getEvaluateInfoTbls() {
		return this.evaluateInfoTbls;
	}

	public void setEvaluateInfoTbls(List<EvaluateInfo> evaluateInfoTbls) {
		this.evaluateInfoTbls = evaluateInfoTbls;
	}

	public EvaluateInfo addEvaluateInfoTbl(EvaluateInfo evaluateInfoTbl) {
		getEvaluateInfoTbls().add(evaluateInfoTbl);
		evaluateInfoTbl.setUserInfoTbl(this);

		return evaluateInfoTbl;
	}

	public EvaluateInfo removeEvaluateInfoTbl(EvaluateInfo evaluateInfoTbl) {
		getEvaluateInfoTbls().remove(evaluateInfoTbl);
		evaluateInfoTbl.setUserInfoTbl(null);

		return evaluateInfoTbl;
	}

	public List<MessageInfo> getMessageInfoTbls() {
		return this.messageInfoTbls;
	}

	public void setMessageInfoTbls(List<MessageInfo> messageInfoTbls) {
		this.messageInfoTbls = messageInfoTbls;
	}

	public MessageInfo addMessageInfoTbl(MessageInfo messageInfoTbl) {
		getMessageInfoTbls().add(messageInfoTbl);
		messageInfoTbl.setUserInfoTbl(this);

		return messageInfoTbl;
	}

	public MessageInfo removeMessageInfoTbl(MessageInfo messageInfoTbl) {
		getMessageInfoTbls().remove(messageInfoTbl);
		messageInfoTbl.setUserInfoTbl(null);

		return messageInfoTbl;
	}

	public List<OilCardInfo> getOilCardInfoTbls() {
		return this.oilCardInfoTbls;
	}

	public void setOilCardInfoTbls(List<OilCardInfo> oilCardInfoTbls) {
		this.oilCardInfoTbls = oilCardInfoTbls;
	}

	public OilCardInfo addOilCardInfoTbl(OilCardInfo oilCardInfoTbl) {
		getOilCardInfoTbls().add(oilCardInfoTbl);
		oilCardInfoTbl.setUserInfoTbl(this);

		return oilCardInfoTbl;
	}

	public OilCardInfo removeOilCardInfoTbl(OilCardInfo oilCardInfoTbl) {
		getOilCardInfoTbls().remove(oilCardInfoTbl);
		oilCardInfoTbl.setUserInfoTbl(null);

		return oilCardInfoTbl;
	}

	public List<OrderInfo> getOrderInfoTbls() {
		return this.orderInfoTbls;
	}

	public void setOrderInfoTbls(List<OrderInfo> orderInfoTbls) {
		this.orderInfoTbls = orderInfoTbls;
	}

	public OrderInfo addOrderInfoTbl(OrderInfo orderInfoTbl) {
		getOrderInfoTbls().add(orderInfoTbl);
		orderInfoTbl.setUserInfoTbl(this);

		return orderInfoTbl;
	}

	public OrderInfo removeOrderInfoTbl(OrderInfo orderInfoTbl) {
		getOrderInfoTbls().remove(orderInfoTbl);
		orderInfoTbl.setUserInfoTbl(null);

		return orderInfoTbl;
	}
	
	public List<OilOrderInfo> getOilOrderInfoTbls() {
		return this.oilOrderInfoTbls;
	}

	public void setOilOrderInfoTbls(List<OilOrderInfo> oilOrderInfoTbls) {
		this.oilOrderInfoTbls = oilOrderInfoTbls;
	}

	public OilOrderInfo addOilOrderInfoTbl(OilOrderInfo oilOrderInfoTbl) {
		getOilOrderInfoTbls().add(oilOrderInfoTbl);
		oilOrderInfoTbl.setUserInfoTbl(this);

		return oilOrderInfoTbl;
	}

	public OilOrderInfo removeOilOrderInfoTbl(OilOrderInfo oilOrderInfoTbl) {
		getOilOrderInfoTbls().remove(oilOrderInfoTbl);
		oilOrderInfoTbl.setUserInfoTbl(null);

		return oilOrderInfoTbl;
	}
	
	public List<StageCarAppointmentInfo> getStageCarAppointmentInfoTbls() {
		return this.stageCarAppointmentInfoTbls;
	}

	public void setStageCarAppointmentInfoTbls(List<StageCarAppointmentInfo> stageCarAppointmentInfoTbls) {
		this.stageCarAppointmentInfoTbls = stageCarAppointmentInfoTbls;
	}

	public StageCarAppointmentInfo addStageCarAppointmentInfoTbl(StageCarAppointmentInfo stageCarAppointmentInfoTbl) {
		getStageCarAppointmentInfoTbls().add(stageCarAppointmentInfoTbl);
		stageCarAppointmentInfoTbl.setUserInfoTbl(this);

		return stageCarAppointmentInfoTbl;
	}

	public StageCarAppointmentInfo removeStageCarAppointmentInfoTbl(StageCarAppointmentInfo stageCarAppointmentInfoTbl) {
		getStageCarAppointmentInfoTbls().remove(stageCarAppointmentInfoTbl);
		stageCarAppointmentInfoTbl.setUserInfoTbl(null);

		return stageCarAppointmentInfoTbl;
	}


//	public List<ShopInfo> getShopInfoTbls() {
//		return this.shopInfoTbls;
//	}
//
//	public void setShopInfoTbls(List<ShopInfo> shopInfoTbls) {
//		this.shopInfoTbls = shopInfoTbls;
//	}

//	public ShopInfo addShopInfoTbl(ShopInfo shopInfoTbl) {
//		getShopInfoTbls().add(shopInfoTbl);
//		shopInfoTbl.setUserInfoTbl(this);
//
//		return shopInfoTbl;
//	}
//
//	public ShopInfo removeShopInfoTbl(ShopInfo shopInfoTbl) {
//		getShopInfoTbls().remove(shopInfoTbl);
//		shopInfoTbl.setUserInfoTbl(null);
//
//		return shopInfoTbl;
//	}

//	public ShopInfo getShopInfoTbl() {
//		return this.shopInfoTbl;
//	}
//
//	public void setShopInfoTbl(ShopInfo shopInfoTbl) {
//		this.shopInfoTbl = shopInfoTbl;
//	}

//	public List<RoleInfo> getRoleInfoTbls() {
//		return this.roleInfoTbls;
//	}
//
//	public void setRoleInfoTbls(List<RoleInfo> roleInfoTbls) {
//		this.roleInfoTbls = roleInfoTbls;
//	}

//	public RoleInfo addRoleInfoTbl(RoleInfo roleInfoTbl) {
//		getRoleInfoTbls().add(roleInfoTbl);
//		roleInfoTbl.setUserInfoTbl(this);
//
//		return roleInfoTbl;
//	}
//
//	public RoleInfo removeRoleInfoTbl(RoleInfo roleInfoTbl) {
//		getRoleInfoTbls().remove(roleInfoTbl);
//		roleInfoTbl.setUserInfoTbl(null);
//
//		return roleInfoTbl;
//	}

	public RoleInfo getRoleInfoTbl() {
		return this.roleInfoTbl;
	}

	public void setRoleInfoTbl(RoleInfo roleInfoTbl) {
		this.roleInfoTbl = roleInfoTbl;
	}
	
	public List<MoneyInfo> getMoneyInfoTbls() {
		return this.moneyInfoTbls;
	}

	public void setMoneyInfoTbls(List<MoneyInfo> moneyInfoTbls) {
		this.moneyInfoTbls = moneyInfoTbls;
	}

	public MoneyInfo addMoneyInfoTbl(MoneyInfo moneyInfoTbl) {
		getMoneyInfoTbls().add(moneyInfoTbl);
		moneyInfoTbl.setUserInfoTbl(this);

		return moneyInfoTbl;
	}

	public MoneyInfo removeMoneyInfoTbl(MoneyInfo moneyInfoTbl) {
		getMoneyInfoTbls().remove(moneyInfoTbl);
		moneyInfoTbl.setUserInfoTbl(null);

		return moneyInfoTbl;
	}

	public List<VipOrderInfo> getVipOrderInfoTbls() {
		return this.vipOrderInfoTbls;
	}

	public void setVipOrderInfoTbls(List<VipOrderInfo> vipOrderInfoTbls) {
		this.vipOrderInfoTbls = vipOrderInfoTbls;
	}

	public VipOrderInfo addVipOrderInfoTbl(VipOrderInfo vipOrderInfoTbl) {
		getVipOrderInfoTbls().add(vipOrderInfoTbl);
		vipOrderInfoTbl.setUserInfoTbl(this);

		return vipOrderInfoTbl;
	}

	public VipOrderInfo removeVipOrderInfoTbl(VipOrderInfo vipOrderInfoTbl) {
		getVipOrderInfoTbls().remove(vipOrderInfoTbl);
		vipOrderInfoTbl.setUserInfoTbl(null);

		return vipOrderInfoTbl;
	}
}