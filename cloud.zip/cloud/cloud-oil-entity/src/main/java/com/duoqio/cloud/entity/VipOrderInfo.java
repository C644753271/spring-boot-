package com.duoqio.cloud.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the vip_order_info_tbl database table.
 * 
 */
@Entity
@Table(name="vip_order_info_tbl")
public class VipOrderInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="vip_order_id")
	private Integer vipOrderId;

	@Temporal(TemporalType.DATE)
	@Column(name="add_time")
	private Date addTime;

	@Column(name="delete_flag")
	private Short deleteFlag;

	@Column(name="vip_order_price")
	private BigDecimal vipOrderPrice;

	@Column(name="vip_order_status")
	private Short vipOrderStatus;

	@Column(name="vip_pay_type")
	private Short vipPayType;

	@Column(name="vip_tran_no")
	private String vipTranNo;

	@Column(name="vip_transaction_id")
	private Integer vipTransactionId;

	//bi-directional many-to-one association to UserInfo
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	@JsonIgnore
	private UserInfo userInfoTbl;

	public VipOrderInfo() {
	}

	public Integer getVipOrderId() {
		return this.vipOrderId;
	}

	public void setVipOrderId(Integer vipOrderId) {
		this.vipOrderId = vipOrderId;
	}

	public Date getAddTime() {
		return this.addTime;
	}

	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}

	public Short getDeleteFlag() {
		return this.deleteFlag;
	}

	public void setDeleteFlag(Short deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public BigDecimal getVipOrderPrice() {
		return this.vipOrderPrice;
	}

	public void setVipOrderPrice(BigDecimal vipOrderPrice) {
		this.vipOrderPrice = vipOrderPrice;
	}

	public Short getVipOrderStatus() {
		return this.vipOrderStatus;
	}

	public void setVipOrderStatus(Short vipOrderStatus) {
		this.vipOrderStatus = vipOrderStatus;
	}

	public Short getVipPayType() {
		return this.vipPayType;
	}

	public void setVipPayType(Short vipPayType) {
		this.vipPayType = vipPayType;
	}

	public String getVipTranNo() {
		return this.vipTranNo;
	}

	public void setVipTranNo(String vipTranNo) {
		this.vipTranNo = vipTranNo;
	}

	public Integer getVipTransactionId() {
		return this.vipTransactionId;
	}

	public void setVipTransactionId(Integer vipTransactionId) {
		this.vipTransactionId = vipTransactionId;
	}

	public UserInfo getUserInfoTbl() {
		return this.userInfoTbl;
	}

	public void setUserInfoTbl(UserInfo userInfoTbl) {
		this.userInfoTbl = userInfoTbl;
	}

}