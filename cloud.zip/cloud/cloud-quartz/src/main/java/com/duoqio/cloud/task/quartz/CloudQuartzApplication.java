package com.duoqio.cloud.task.quartz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudQuartzApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(CloudQuartzApplication.class, args);
	}
}
