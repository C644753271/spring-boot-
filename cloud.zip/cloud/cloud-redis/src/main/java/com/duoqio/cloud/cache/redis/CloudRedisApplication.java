package com.duoqio.cloud.cache.redis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudRedisApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(CloudRedisApplication.class, args);
	}

}
